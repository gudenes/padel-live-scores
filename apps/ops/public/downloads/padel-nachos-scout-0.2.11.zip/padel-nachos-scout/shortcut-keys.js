// Shared by the panel, worker and isolated video remote.
(()=>{
 if(globalThis.__pnMediaKeys)return;
 const defaults={back10:{key:'j'},pause:{key:'Home'},forward30:null,back5:{key:'Insert'},forward5:{key:'PageUp'},forward10:{key:'l',shift:true},speed:null,forward90:{key:'k',shift:true}};
 const actions={back10:'Back 10 seconds',pause:'Play / pause',forward30:'Forward 30 seconds',back5:'Back 5 seconds',forward5:'Forward 5 seconds',forward10:'Forward 10 seconds',speed:'Cycle playback speed',forward90:'Forward 90 seconds'};
 function normalize(raw){
  // Migrate the former default speed shortcut to the requested 90-second skip.
  if(raw&&raw.forward90===undefined&&raw.speed?.key?.toLowerCase()==='k'&&raw.speed.shift&&!raw.speed.ctrl&&!raw.speed.alt&&!raw.speed.meta)raw={...raw,speed:null};
  const out={};
  for(const action of Object.keys(actions)){
   const value=raw?.[action]===undefined?defaults[action]:raw[action];
   if(value===null){out[action]=null;continue;}
   if(!value||typeof value.key!=='string'||!value.key.length||value.key.length>32||['Control','Meta','Alt','Shift','Tab','Escape','Backspace','Delete','Dead','Unidentified'].includes(value.key))throw Error('Choose a letter, number, arrow, navigation or function key.');
   out[action]={key:value.key.length===1?value.key.toLowerCase():value.key,ctrl:!!value.ctrl,alt:!!value.alt,shift:!!value.shift,meta:!!value.meta};
  }
  // Adding new actions must not steal an existing custom combination.
  if(raw)for(const action of ['forward10','speed','forward90'])if(raw[action]===undefined&&out[action]&&Object.entries(out).some(([other,b])=>other!==action&&b&&JSON.stringify(b)===JSON.stringify(out[action])))out[action]=null;
  const keys=Object.values(out).filter(Boolean).map(b=>JSON.stringify(b));
  if(new Set(keys).size!==keys.length)throw Error('That shortcut is already assigned to another action.');
  return out;
 }
 function upgradeFastBindings(raw){
  const out=normalize(raw),requested={back5:{key:'Insert'},pause:{key:'Home'},forward5:{key:'PageUp'}};
  for(const action of Object.keys(out))if(!(action in requested)&&Object.values(requested).some(b=>out[action]?.key===b.key&&!out[action].ctrl&&!out[action].alt&&!out[action].shift&&!out[action].meta))out[action]=null;
  return normalize({...out,...requested});
 }
 function label(binding){if(!binding)return 'Unassigned';return [binding.ctrl?'Ctrl':null,binding.alt?'Alt':null,binding.shift?'Shift':null,binding.meta?'⌘':null,binding.key===' '?'Space':binding.key==='ArrowLeft'?'←':binding.key==='ArrowRight'?'→':binding.key.length===1?binding.key.toUpperCase():binding.key].filter(Boolean).join('+');}
 function matches(event,binding){return !!binding&&(event.key.length===1?event.key.toLowerCase():event.key)===binding.key&&!!event.ctrlKey===!!binding.ctrl&&!!event.altKey===!!binding.alt&&!!event.shiftKey===!!binding.shift&&!!event.metaKey===!!binding.meta;}
 function attach({target,controls,getBindings,isActive=()=>true}){
  const handler=event=>{
   if(!isActive()||event.repeat||event.isComposing||target.querySelector?.('#scouting-menu[open]'))return;
   const focused=event.composedPath()[0];if(focused?.matches?.('input,textarea,select,[contenteditable]')||focused?.isContentEditable)return;
   // Reserve standard Undo for scouting; media shortcuts must not steal it.
   if(event.key.toLowerCase()==='z'&&(event.ctrlKey||event.metaKey)&&!event.altKey&&!event.shiftKey)return;
   // Keep letter/number shot shortcuts available inside the scoring dialog.
   if(target.querySelector?.('#shot-dialog[open]'))return;
   if(target.querySelector?.('dialog[open]')&&(/^[a-z0-9]$/i.test(event.key)||[' ','Enter'].includes(event.key))&&!event.ctrlKey&&!event.altKey&&!event.metaKey)return;
   const action=Object.keys(controls).find(name=>matches(event,getBindings()[name]));
   if(!action)return;event.preventDefault();event.stopImmediatePropagation();if(!controls[action].disabled)controls[action].click();
  };
  target.addEventListener('keydown',handler,true);return ()=>target.removeEventListener('keydown',handler,true);
 }
 function attachUndo({target,control,isActive=()=>true}){
  const handler=event=>{
   if(!isActive()||event.defaultPrevented||event.repeat||event.isComposing||event.altKey||event.shiftKey||!(event.ctrlKey||event.metaKey)||event.key.toLowerCase()!=='z'||target.querySelector?.('#scouting-menu[open]'))return;
   const focused=event.composedPath()[0];
   // Leave native text editing undo alone, including inputs inside the shot dialog.
   if(focused?.matches?.('input,textarea,select,[contenteditable]')||focused?.isContentEditable)return;
   const button=control();if(!button||button.disabled)return;
   event.preventDefault();event.stopImmediatePropagation();button.click();
  };
  target.addEventListener('keydown',handler,true);return ()=>target.removeEventListener('keydown',handler,true);
 }
 globalThis.__pnMediaKeys={attachUndo,defaults:normalize(defaults),actions,normalize,upgradeFastBindings,label,attach};
})();
